package com.ThunderGod.warehouse;
import com.ThunderGod.warehouse.*;
import android.widget.LinearLayout;
import android.app.Activity;
import android.widget.PopupWindow;
public class TextUI {
    public static PopupWindow TextUIs;
  public static void TextUI(Activity context){
      final LinearLayout TextUI1=TView.TView(context, null, "CC", 1,(int)(TGmixed.W(context)), (int)(TGmixed.H(context)), "#22000000", 0, "TB", 0,null,null);
      final LinearLayout TextUI2=TView.TView(context, TextUI1, "CC", 1,(int)(TGmixed.W(context)*0.48), (int)(TGmixed.H(context)*0.65), "#ffffff", 30, "TB", 0,null,null);
      local.UIFadein(TextUI1, 0, 100, 400);
      local.UIPlumb(TextUI1, 20, 0, 400);
      local.UIZoom(TextUI1, "TP", 1.1f, 1, 400);
      TextUIs=Tpopup.TCdv(TextUI1, TextUI1, "CC", false, true, true, false, TGmixed.W(context), TGmixed.H(context), "Di", 0, 0);
   }
    
    
}
