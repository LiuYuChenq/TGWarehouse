package com.ThunderGod.warehouse;
import android.widget.LinearLayout;
import android.app.Activity;
public class ButtonS {
    public static LinearLayout ButtonS(Activity context,int W,int H,String buttoncolor,int fillet){
        final LinearLayout ButtonS1=TView.TView(context, null, "CC", 1,W, H, "#00000000", 0, "TB", 50,null,null);
        final LinearLayout ButtonS2=TView.TView(context, ButtonS1, "CC", 1,W-(int)(TGmixed.W(context)*0.01), H-(int)(TGmixed.H(context)*0.01),buttoncolor,fillet, "TB", 0,null,null);
       return ButtonS1;
     }
    
    
}
