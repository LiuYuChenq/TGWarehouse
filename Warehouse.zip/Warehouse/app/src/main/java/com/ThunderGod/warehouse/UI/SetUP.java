package com.ThunderGod.warehouse.UI;
import com.ThunderGod.warehouse.*;
import android.widget.LinearLayout;
import android.content.Context;
import android.view.View;
import android.app.Activity;
import android.widget.PopupWindow;
public class SetUP {
    public static boolean setup1=false;
    public static boolean setup2=false;
    public static boolean setup3=false;
    public static LinearLayout SetUPUI(final Activity context) {
        final LinearLayout SetUP=TView.TView(context, null, "CT", 1, null, null, "#00000000", 50, "TB", 0, null, null);
        TextButton.TextButton(context, SetUP, "ModScript", (int)(TGmixed.W(context) * 0.15), (int)(TGmixed.H(context) * 0.1), new int[]{50,50,50,50}, true, setup1,
            new View.OnClickListener(){  
                @Override
				public void onClick(View view) {
                    if (setup1 == false) {
                        setup1 = true;
                        ModScript.ModScript(context);
                        //测试1(context);
                    } else
                    if (setup1 == true) {
                        setup1 = false;
                        //cs1.dismiss();
                        ModScript.ModScriptUI.dismiss();
                    }

                }});
        TextButton.TextButton(context, SetUP, "测试", (int)(TGmixed.W(context) * 0.15), (int)(TGmixed.H(context) * 0.1), new int[]{50,50,50,50}, false, false, new View.OnClickListener(){  
                @Override
				public void onClick(View view) {
                //未完成TextUI.TextUI(context);
                }});
        TextButton.TextButton(context, SetUP, "测试", (int)(TGmixed.W(context) * 0.15), (int)(TGmixed.H(context) * 0.1), new int[]{50,50,50,50}, false, setup3, null);
        /*
                                                      长                                  宽
         TextButton.TextButton(context, 上层布局, 文本, (int)(TGmixed.W(context) * 0.15), (int)(TGmixed.H(context) * 0.1), 圆角大小, 是否点击换色, 判断的布尔值,
         new View.OnClickListener(){  
         @Override
         public void onClick(View view) {
         if (判断的布尔值 == false) {
         判断的布尔值 = true;
         
         } else
         if (判断的布尔值 == true) {
         判断的布尔值 = false;
     
         }
         如果要点击不换色，让是否换色为false  判断的布尔值为false 点击器里不用加if
         }});
        */
        return SetUP;
    }
}
