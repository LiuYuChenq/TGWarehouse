package com.ThunderGod.warehouse;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Toast;
import android.util.DisplayMetrics;
import android.widget.Button;
import android.view.View;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.view.Gravity;
import android.widget.PopupWindow;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import com.ThunderGod.warehouse.*;
import android.graphics.drawable.Drawable;
import android.content.Context;
import android.view.View.OnLongClickListener;
import android.view.View.OnLayoutChangeListener;
import android.view.Window;
import android.os.Build;
import android.view.animation.RotateAnimation;
import android.view.animation.LinearInterpolator;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.view.animation.ScaleAnimation;
import android.animation.ValueAnimator;
import android.util.Log;
import java.util.stream.LongStream;
import com.ThunderGod.warehouse.UI.UI;
import android.widget.ScrollView;
import com.ThunderGod.warehouse.UI.SetUP;
import com.ThunderGod.warehouse.UI.*;
public class MainActivity extends Activity {
    TextButton TextButton=new TextButton();
    private static boolean c=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		TGmixed.hideStatusBar(this);

		new Handler(Looper.getMainLooper()).postDelayed(new Runnable(){
				@Override
				public void run() {
					UI.TGtext(MainActivity.this, MainActivity.this);
             
                }
			}, 1000);
    }

	public int W() {
		DisplayMetrics metrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(metrics);
		return (int) metrics.widthPixels;
	}
	public int H() {
		DisplayMetrics metrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(metrics);
		return (int) metrics.heightPixels;
	}
    
     PopupWindow cs1;
     public void 测试1() {
     cs1 = ButtonMove.ButtonMove(this, "测1", (int)(H() * 0.1), (int)(H() * 0.1), 200, 200,true,c,  new View.OnClickListener(){
     @Override
     public void onClick(View view) {
     Toasts.Toasts(getApplicationContext(), "测试T", "cs");
     if(c==false){
     c = true;
     }else{
     c = false;
     }
     }
     });
     }
     
	PopupWindow cs2;
	public void 测试2() {
		cs2 = ButtonMove.ButtonMove(this, "测2", (int)(H() * 0.1), (int)(H() * 0.1), 500, 200, false, false,  new View.OnClickListener(){
				@Override
				public void onClick(View view) {
					Toasts.Toasts(getApplicationContext(), "测试T", "Ts");
					//jss=true;
				}
			});
	}
    
}



 
